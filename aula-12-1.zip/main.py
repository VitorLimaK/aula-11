


#========================================================
dic = {'salgado': 4.50
      'lanche': 6.50
      'suco':3.00
      'refrigerante':3.50
      'doce' : 1.00}


#==-=-=-=-=-=-=-=-==-=-=-=-==-==-=-=-=-=-=-=-=-=-=--=-=-

print = {'arroz': 17:30, 'feijao':12:50, 'carne': 23.90,'salada': 3.40}

d['carne'] = 25.0
d['tomato'] = 8.80
print(
                                                                                                           
)


#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-
L = [5, 7, 2, 9 , 4 ,1 ,3, 90]

print('lista = ', L)
print('O tamanho da lista é', len (L))
print('O maior elemento da lista é ',max(L))
print("o menor elemento da lista é ",min(L))
print('a soma dos elmentos da lista é ',sum(L))
L.sort()
print("Lista em ordem crescente: ",L)
L.reverse()
print("lista em ordem decrescente: ",L)
