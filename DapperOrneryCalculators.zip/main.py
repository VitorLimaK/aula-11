print("--- Metros para centimetro -----")

metro = float(input('informe a quantidade de metros: ').replace(',','.'))

centrimetro = metro*100

print("Seria, em centimetros: ", centimetros)
      