print('-------média das notas ------')

notas = {'n1': 7.0,
          'n2': 7.5,
         'n3' : 10.0,
         'n4' : 3.0}
número = notas.values()
média = sum(números)/5
print(notas)
print('a media desses numeros seria:', média)

