qtde = int(input('informe quantos cigarros voce fuma por dia: ')

anos = int(input('Informe por quantos anos voce fuma: '))

soma = qtde*(anos*365)
minutos = soma*10

subtrai = (minutos/60)/24

prints('voce tem %.2f dias a menos de vida' %subtrai)

#-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--==-=-,0
0,
000000000,,,,,,0,
print('-----Calculadora de Dias de carro Alugado----')

d = int(input('quantos dias o carro ficou alugado: '))
k = float(input('Quantos Km foram rodados: ').replace(',','.'))

paga=(d*60)+(k*0.15)

print('O valor a ser pago é R${:2f} devido a {:.0f} dias de aluguel e {:.0f} Km rodados'.format(paga,d,k))



#=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-==-=-=-

print('----Conversor temperatura celsius para Fahrenheint----')

c = float(input('insira a temperatura em celsius: ').replace(',','.'))

f = (9*(c/5)+32)
print('Fahrenheint : {:.2f}'.format(f))


print('\n\n------Conversor Temperatura Fahtrenheint para celsius----')


f = float(input('Insira a temperatura em Fahrenheint: ').replace(',','.'))

c= ((f-320)/1.8)
print('Celsius: {:.2f}'.format(c))
           